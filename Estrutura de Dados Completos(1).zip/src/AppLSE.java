
public class AppLSE {
    public static void main(String[] args){
        
        LSE lista = new LSE();

        lista.inserirNo(new ItemLSE(10));
		lista.inserirNo(new ItemLSE(15));
		lista.inserirNo(new ItemLSE(50));
		lista.inserirNo(new ItemLSE(40));
        lista.inserirNo(new ItemLSE(15));
		lista.inserirNo(new ItemLSE(50));
        lista.inserirNo(new ItemLSE(18));
		lista.inserirNo(new ItemLSE(5));
        lista.inserirNo(new ItemLSE(12));
		lista.inserirNo(new ItemLSE(54));
        lista.inserirNo(new ItemLSE(27));
		lista.inserirNo(new ItemLSE(59));
        lista.inserirNo(new ItemLSE(19));
		lista.inserirNo(new ItemLSE(58));
		System.out.println(lista.toString());
        System.out.println(lista.removerNo(40));
        lista.removerPartido(10);
        lista.removerPrimeiroNo();
        System.out.println(lista);


    }
        
        
    

   


    
}
   