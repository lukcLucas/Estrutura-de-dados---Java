public class NoABB {
	
	 private int valor;
     private NoABB esq;
     private NoABB dir;

     //busca na arvore

     public NoABB(int valor){
        this.valor = valor;
        this.esq = null;
        this.dir = null;
     }

  public static void montaArvore(NoABB novo, NoABB arvore){
       if(arvore == null){
           arvore = novo;
       }else{
            if(novo.valor < arvore.valor){
                if(arvore.esq == null){
                    arvore.esq = novo;
                }else{
                    montaArvore(novo, arvore.esq);
                }
            }else{
                  if(arvore.dir == null){
                      arvore.dir = novo;
                  }else{
                      montaArvore(novo, arvore.dir);
                  }
            }
       }
  }

  public static boolean BuscaNo(NoABB arvore, int valor){
      boolean ret = false;
      if(arvore == null){ //nao achou o no
        ret = false;
      }else if(arvore.valor == valor){  //achou o no arvore
        ret = true;
      }else{
           if(arvore.valor > valor){
                ret =BuscaNo(arvore.esq, valor);
           }else{
               ret = BuscaNo(arvore.dir, valor);
           }
      }
      return ret;
  }

  public static void imprimirPreOrdem(NoABB n){
    System.out.print(n.valor + "  ");
    
    if(n.esq != null){
        imprimirPreOrdem(n.esq);
     }else if(n.dir != null){
        imprimirPreOrdem(n.dir);
     }

    
   
 }

 public static void imprimirEmOrdem(NoABB n){
       
    if(n.esq != null){
        imprimirEmOrdem(n.esq);

     }

     System.out.print(n.valor + "  ");
     
      if(n.dir != null){
        imprimirEmOrdem(n.dir);
     }
 }

 public static void imprimirPosOrdem(NoABB n){
       
    if(n.esq != null){
        imprimirPosOrdem(n.esq);

     }

    
     
      if(n.dir != null){
        imprimirPosOrdem(n.dir);
     }

     System.out.print(n.valor + "  ");
 }






	
	
}
