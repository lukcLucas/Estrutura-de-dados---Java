public class Pilha<T> extends EstruturaEstatica<T> {
    
    public Pilha(){
        super();
    }


    public Pilha(int capacidade){

        super(capacidade);
    }

    //Empilhar elemento da pilha (adicionar ou push)
    public void empilha(T elemento){
      this.aumentaCapacidade();

      this.elementos[tamanho] = elemento;
      tamanho++;
      
    }

    //verificar se pilha esta vazia 

    public boolean estaVazia(){

        return tamanho ==0;
    }

    //metodo espiar/verificar elemento do topo (peek) da pilha 

    public T topo(){
        if(this.estaVazia()){
            return null;
        }
        return this.elementos[tamanho-1];
    }

    // desempilhar elemento (pop)

    public T desempilha(){
        if(this.estaVazia()){
            return null;
        }
        /*
        T elemento = this.elementos[tamanho-1]
        tamanho--
        return elemento*/
      //Simplificar o codigo 

      return this.elementos[--tamanho];
    }






    
    

}
