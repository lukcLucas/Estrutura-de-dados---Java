public class AppFila {
   public static void main(String[] args) {
    Fila<Integer> fila = new Fila<>();
   
    
    System.out.println(fila.estaVazia()); //true
    System.out.println(fila.tamanho()); // 0
    
    fila.enfileirar(5);
    fila.enfileirar(4);
    fila.enfileirar(1);
    fila.enfileirar(2);
    fila.enfileirar(3);

    System.out.println(fila.estaVazia()); //false
    System.out.println(fila.tamanho()); // 3
    System.out.println(fila.toString());
    System.out.println(fila.espiar());
    System.out.println(fila.desenfileirar());//5
    System.out.println(fila.toString());
   System.out.println(fila.desenfileirar());
   System.out.println(fila);

    
   }
}
