public class NoDupla {
    
     private int info;
     private NoDupla ant, prox;
     /**
      * 
        Entao, cada nó possui duas referencias 
        - a primereira aponta para o nó predecessor
        -a segunda aponta para o nó sucessor

        LDE --> Pode percorrer a lista tanto do inicio para 
        o fim quanto do fim para o inicio,assim como voltar ao nó anteririor,caso
      */
     /**
      * @param info
      */

      public NoDupla(int info){

        this.info = info;

      }

      public int getInfo(){
          return info;
      }

      public void setInfo(int info){
          this.info = info;
      }

      public NoDupla getAnt(){
          return ant;
      }

      public void setAnt(NoDupla ant){
          this.ant = ant;
      }

      public NoDupla getProx(){
          return prox;
      }

      public void setProx(NoDupla prox){
          this.prox = prox;
      }

}
