import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;
public class APIFilaQueue {
    
    public static void main(String[] args) {
        
      Queue<Integer> fila = new LinkedList<>();
      Queue<Integer> filaComPrioridade = new PriorityQueue<>();

      fila.add(1); //enqueue
      fila.add(2);

      System.out.println(fila);
      System.out.println(fila.peek()); // espiar
      System.out.println(fila.remove()); // dequeue
      System.out.println(fila);


      //Api java PriorityQueue
        
      filaComPrioridade.add(3);
      filaComPrioridade.add(2);

      System.out.println(filaComPrioridade);



    }
}
