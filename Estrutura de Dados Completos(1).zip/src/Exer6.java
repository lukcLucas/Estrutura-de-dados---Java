import java.util.Scanner;
public class Exer6 {
    /*
    Ultilize a classe Lista e classe contato(criado durante as aula) e desenvolva os seguintes itens
    1-crie um vetor com capacidade para 20 contato
    2-insira 30 contato no vetor(isso e possivel ser feito atraves de um loop)
    crie um exemplo para ultilizar cada metodo da lista
    */
    public static void main(String[] args) {
        //criacao das variaveis 

        Scanner sc = new Scanner(System.in);
           
        //criar lista com 20 de capacidade 
        ListaGenerics<Contato> lista = new ListaGenerics<>(20);

        //criar e adicionar 30 contato

        criarContatosDinamicamente(5, lista);

        //criar um menu para que o usuario escolha a opcao
         int opcao = 1;

         while(opcao != 0){
             opcao = obterOpcaoMenu(sc);

            switch(opcao){
             case 1:
              adicionarContatoFinal(sc, lista);
              break;

             case 2:
               adicionarContatoPosicao(sc, lista);
              break;

             case 3:
              obtemContatoPosicao(sc, lista);
              break;

             case 4:
             obtemContato(sc, lista);
              break;
             
             case 5:
              pesquisarUltimoIndice(sc, lista);
              break;

             case 6:
              pesquisarContatoExiste(sc, lista);
              break;

             case 7:
              ExcluirPorPosicao(sc, lista);
              break;

             case 8:
              ExcluirPorContato(sc, lista);
              break;

             case 9:
              ImprimeTamanhoLista(lista);
              break;

             case 10:
              LimparLista(lista);
              break;

             case 11:
             ImprimeTamanhoLista(lista);
              break;



              default:
                 break;




            }




         }

        System.out.println("Usuario digitou 0,programa terminado");
    
    }


    private static void ImprimirLista(ListaGenerics<Contato> lista){
        System.out.println(lista);    
    }
      









    private static void LimparLista(ListaGenerics<Contato> lista){
        lista.limpar();  
        System.out.println("Todo os contatos do vetor foram excluidos");     
    }
        




    private static void ImprimeTamanhoLista(ListaGenerics<Contato> lista){
System.out.println("Tamanho da lista e de :" +lista.tamanho());
    }







    private static void ExcluirPorContato(Scanner sc, ListaGenerics<Contato> lista){
        int pos = leInformacaoInt("Entra com a posicao a ser removido", sc);
          
        try{
          Contato contato = lista.busca(pos);
          lista.remove(contato);
          System.out.println("Contato Excluido");
           
       }catch(Exception e){
           System.out.println("Posicao Invalida");
       }
    
    }





















    private static void ExcluirPorPosicao(Scanner sc, ListaGenerics<Contato> lista){
        int pos = leInformacaoInt("Entra com a posicao a ser removido", sc);
          
        try{
          lista.remove(pos);
          System.out.println("Contato Excluido");
           
       }catch(Exception e){
           System.out.println("Posicao Invalida");
       }
    
    }















    private static void pesquisarContatoExiste(Scanner sc, ListaGenerics<Contato> lista){
        int pos = leInformacaoInt("Entra com a posicao a ser pesquisada", sc);
          
        try{
           Contato contato = lista.busca(pos);
           boolean existe = lista.contem(contato);

           if(existe){
            System.out.println("Contato existe, segue dados:");
            System.out.println(contato);
            
 
           }else{
            System.out.println("Contato nao existe");
           }
           
       }catch(Exception e){
           System.out.println("Posicao Invalida");
       }
    
    }











    private static void pesquisarUltimoIndice(Scanner sc, ListaGenerics<Contato> lista){
        int pos = leInformacaoInt("Entra com a posicao a ser pesquisada", sc);
          
        try{
           Contato contato = lista.busca(pos);
           System.out.println("Contato existe, segue dados:");
           System.out.println(contato);
           System.out.println("Fazendo Pesquisa do ultimo indice do contrato encontrado :");
           pos = lista.ultimoIndice(contato);

           System.out.println(("Contato encontrado na posicao") +pos);
           
       }catch(Exception e){
           System.out.println("Posicao Invalida");
       }
    
    }














    private static void obtemContato(Scanner sc, ListaGenerics<Contato> lista){
        int pos = leInformacaoInt("Entra com a posicao a ser pesquisada", sc);
          
        try{
           Contato contato = lista.busca(pos);
           System.out.println("Contato existe, segue dados:");
           System.out.println(contato);
           System.out.println("Fazendo Pesquisa do contato encontrado:");
           pos = lista.busca(contato);

           System.out.println(("Contato encontrado na posicao") +pos);
           
       }catch(Exception e){
           System.out.println("Posicao Invalida");
       }
    
       }










  private static void obtemContatoPosicao(Scanner sc, ListaGenerics<Contato> lista){
     int pos = leInformacaoInt("Entra com a posicao a ser pesquisada", sc);
       
     try{
        Contato contato = lista.busca(pos);
        System.out.println("Contato existe, segue dados:");
        System.out.println(contato);
    }catch(Exception e){
        System.out.println("Posicao Invalida, contato nao adicionado");
    }
 
    }








   private static void adicionarContatoFinal(Scanner sc, ListaGenerics<Contato> lista){
        System.out.println("Criando um contato, entre com as informacoes:");
        String nome = leInformacao("Entre com o nome",sc);
        String telefone = leInformacao("Entre com o telefone",sc);
        String email = leInformacao("Entre com o email",sc);

        Contato  contato = new Contato(nome, telefone, email);
   }



   private static void adicionarContatoPosicao(Scanner sc, ListaGenerics<Contato> lista){

    System.out.println("Criando um contato, entre com as informacoes:");
    String nome = leInformacao("Entre com o nome",sc);
    String telefone = leInformacao("Entre com o telefone",sc);
    String email = leInformacao("Entre com o email",sc);

    Contato  contato = new Contato(nome, telefone, email);

    int pos = leInformacaoInt( "Entre com  a posica a adicionar o contato ",sc);
   

    try{
        lista.adiciona(pos, contato);
        System.out.println("Contato adicionado com sucesso!");
        System.out.println(contato);
    }catch(Exception e){
        System.out.println("Posicao Invalida, contato nao adicionado");
    }

    
}


protected static String leInformacao(String msg, Scanner sc){

    System.out.println(msg);
    String entrada = sc.nextLine();

    return entrada;
}

protected static int leInformacaoInt(String msg, Scanner sc){

    boolean entradaValida = false;
    int num = 0;

    while (!entradaValida){

        try {

            System.out.println(msg);
            String entrada = sc.nextLine();

            num = Integer.parseInt(entrada);

            entradaValida = true;

        } catch (Exception e){
            System.out.println("Entrada inválida, digite novamente");
        }
    }

    return num;
}



    protected static int obterOpcaoMenu(Scanner sc){

        boolean entradaValido = false;
        int opcao = 0;
        String entrada;

        do{

            System.out.println("Digite a opcao desejada:");
            System.out.println("1: Adiciona contato no final da lista");
            System.out.println("2: Adiciona contato em uma posicao especifica");
            System.out.println("3: Obtem contato de uma posicao especifica");
            System.out.println("4: Consulta contato ");
            System.out.println("5: Consulta ultimo indice do contato  ");
            System.out.println("6: Verifica se contato existe ");
            System.out.println("7: Excluir por posicao ");
            System.out.println("8: Excluir contato ");
            System.out.println("9: Verifica tamanho da lista  ");
            System.out.println("10: Excluir todos os contatos da lista ");
            System.out.println("11: Imprime lista  ");
            System.out.println("0: Sair ");

           try{
             entrada = sc.nextLine();
             opcao = Integer.parseInt(entrada);

            if(opcao >= 0 && opcao <= 11){
                entradaValido = true;
            }else{
                throw new Exception();
            }

           }catch(Exception e){
               System.out.println("Entrada Invalida, digita novamente");
           }
    

        }while(!entradaValido);

        

        return opcao;
    }

   private static void criarContatosDinamicamente(int quantidade, ListaGenerics<Contato>lista){

    Contato contato = new Contato();

       for(int i=1;i<=quantidade;i++){
           
           contato.setNome("Contato" + i);
           contato.setTelefone("11111111"+i);
           contato.setEmail("contato"+i+"@gmail.com");
           
           
           lista.adiciona(contato);
       }
   }


}
