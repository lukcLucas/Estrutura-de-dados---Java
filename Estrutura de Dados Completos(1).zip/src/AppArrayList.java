
import java.util.ArrayList;

public class AppArrayList {
    public static void main(String[] args) {

        ArrayList<String> arrayList = new  ArrayList<String>(5);

      //  ListaGenerics<String> array = new ListaGenerics<String>(1)


        //array.adiciona("elemento")






       //funcao arrayList
       
       // metodo para adicionar 

        arrayList.add("A");
        arrayList.add("B");
        arrayList.add("C");
        

        System.out.println(arrayList);//imprimir

        arrayList.add(2, "D"); //indice, elemento 

        System.out.println(arrayList);//imprimir

        //metodo de busca 

        boolean existe = arrayList.contains("A");

        if(existe){
            System.out.println("Existe no array");
        }else{
            System.out.println("nao existe no array");
        }

        System.out.println(arrayList);

          
        int pos = arrayList.indexOf("B");

        
        if(pos > -1){
            System.out.println("Existe no array");
        }else{
            System.out.println("nao existe no array");
        }
       
        // busca por posicao

        System.out.println(arrayList.get(2));

        // metodo para remover 

        arrayList.remove(0);

        System.out.println(arrayList);


        // metodo tamanho 

        System.out.println(arrayList.size());


        System.out.println(arrayList);

        //metodo ultimo indice 

        System.out.println(arrayList.lastIndexOf("B"));


        arrayList.add("A");
        arrayList.add("B");
        arrayList.add("C");

       //Metodo clear

       arrayList.clear();
       System.out.println(arrayList);


    }
}
