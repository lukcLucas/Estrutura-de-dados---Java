public class AppDesafioPilha04 {
    
    //desafio torre de hanoi

    public static void main(String[] args) {

        Pilha<Integer> original = new Pilha<>();  
        Pilha<Integer> dest = new Pilha<>(); 
        Pilha<Integer> aux = new Pilha<>();  
        
        original.empilha(4);
        original.empilha(3);
        original.empilha(2);
        original.empilha(1);

        torreDeHanoi(original.tamanho(), original, dest, aux);
    }

    public static void torreDeHanoi(int i, Pilha<Integer> original, Pilha<Integer> dest, Pilha<Integer> aux){
        if(i > 0){
            torreDeHanoi(i-1, original, aux, dest);
			dest.empilha(original.desempilha());
			System.out.println("------");
			System.out.println("Original: " + original);
			System.out.println("Destino: " + dest);
			System.out.println("Aux: " + aux);
			torreDeHanoi(i-1, aux, dest, original);
        }
    }



}
