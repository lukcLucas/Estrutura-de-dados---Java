public class AppLista {
    public static void main(String[] args) {
       // ListaContg lista = new ListaContg(3)

        ListaContgObjeto q = new ListaContgObjeto(3);
        

     

       
        q.adiciona(1); // verificar o elementos da lista 
        q.adiciona(2); 
        q.adiciona(3);
        q.adiciona(4);
        q.adiciona(5);

        System.out.println(" lista ");
        System.out.println(q);
        System.out.println("Tamanho da lista ");
        System.out.println(q.tamanho());
        //System.out.println(q.toString())
        System.out.println("Buscando na lista ");
        System.out.println(q.busca(2));
    

        System.out.println(q); // imprimir lista 
        
        System.out.println("Add na lista ");
        q.adiciona(0, 30);
        q.adiciona(1, 30);

        System.out.println(q);


        System.out.println(" Remover da lista ");
        q.remove(1);

        System.out.println(q);

        //remover o elemento da lista
        int pos = q.busca("4");
        if(pos > -1){
            q.remove(pos);
        }else{
            System.out.println("Elemento  nao existe na lista  ");
        }
        System.out.println(q);


    }
}
