public class LSE {
   
    private NoLSE prim;
	private NoLSE ult;
	private int nElem;

	public LSE(){
		this.prim = null;
		this.ult = null;
		this.nElem = 0;
	}
	public NoLSE getPrim() {
		return this.prim;
	}
	public void setPrim(NoLSE novo) {
		this.prim = novo;
	}
	public NoLSE getUlt() {
		return this.ult;
	}
	public void setUlt(NoLSE novo) {
		this.ult = novo;
	}
	public int getQuantNos() {
		return this.nElem;
	}
	public void setQuantNos(int novo) {
		this.nElem = novo;
	}
	public boolean eVazia(){   //será usando em métodos de pesquisa e remoção
		return this.prim==null;
	}
	//------------------------------------------------------
	//inserir um nó no final da lista
	public void inserirNo (ItemLSE novo){
		NoLSE novoNo = new NoLSE(novo);
		if (this.eVazia()){
			this.prim = novoNo;
		}else{
			this.ult.setProx(novoNo);
		}
		this.ult = novoNo;
		this.nElem++;
	}
	//retorna o endereço do nó que está contendo o valor a ser procurado.
	public NoLSE pesquisarNo (int chave){
		NoLSE atual = this.prim;
		while ((atual != null) && (atual.getInfo().getChave() != chave)){
			atual = atual.getProx();
		}	
		return atual;
	}
	//remove um determinado nó em qualquer posição na lista.
	public boolean removerNo (int chave) {
		NoLSE atual = this.prim;
		NoLSE ant = null;
		if (eVazia()){
			return false;
		} else {
			while ((atual != null)&&(atual.getInfo().getChave()!= chave)){
				ant = atual;
				atual = atual.getProx();
			}
			if (atual == null){
				return false;
			}
			else{
				if (atual == this.prim){
					if (this.prim == this.ult){
						this.ult = null;
					}
					this.prim = this.prim.getProx();
				} else {
					if (atual == this.ult){
						this.ult = ant;
					}
					ant.setProx(atual.getProx());
				}
				this.nElem--;
				return true;
			}
		}
	}
	//outra forma de escrever o método para remover determinado Nó
	public boolean removerNo2(int x){
		if (this.eVazia()){
			return false;
		}else{
			if (this.prim.getInfo().getChave()==x){
				if (this.prim.getProx()==null){//se for único nó da lista
					this.ult = null;
				}
				//remover o primeiro nó da lista
				this.prim = this.prim.getProx();
				this.nElem--;
				return true;
			}else{
				NoLSE atual = this.prim;
				while ((atual.getProx()!=null)&&
						(atual.getProx().getInfo().getChave()!=x)){
					atual = atual.getProx();
				}
				if (atual.getProx()==null){//não achou o valor na lista
					return false;
				}else{
					if (atual.getProx()==this.ult){//se for o último nó
						atual.setProx(null);
						this.ult = atual;
					}else{	//remove o nó no meio da lista
						atual.setProx(atual.getProx().getProx());
					}
					this.nElem--;
					return true;
				}
			}
		}
	}
	//mostrar conteúdo da lista
	public String toString(){
		String msg = "";
		NoLSE atual = this.prim;
		while (atual != null){
			msg += atual.getInfo().getChave()+"\n";
			atual = atual.getProx();
		}
		return msg;
	}
	//inserir um novo nó após determinado nó
	public boolean inserirAposDeterminado(int x, ItemLSE elem){
		if (this.eVazia()){
			return false;
		}else{
			NoLSE atual = this.prim;
			//procurar o nó com o valor de x
			while (atual != null && atual.getInfo().getChave()!=x){
				atual = atual.getProx();
			}
			if (atual==null){    //não o achou o x
				return false;
			}else{
				NoLSE novoNo = new NoLSE(elem);
				if (atual==this.ult){     
					this.ult.setProx(novoNo);
					this.ult = novoNo;
				}else{
					novoNo.setProx(atual.getProx());
					atual.setProx(novoNo);
				}
				this.nElem++;
				return true;
			}
		}
	}
	//outra solução - inserir um novo nó após determinado nó
	public boolean inserirAposDeterminado2(int x, ItemLSE elem){
		if (this.eVazia()){
			return false;
		}else{
			NoLSE atual = this.prim;
			//procurar o nó com o valor de x
			while (atual != null && atual.getInfo().getChave()!=x){
				atual = atual.getProx();
			}
			if (atual==null){    //não o achou o x
				return false;
			}else{
				NoLSE novoNo = new NoLSE(elem);
				if (atual!=this.ult){     
					novoNo.setProx(atual.getProx());
				}else{	
					this.ult = novoNo;
				}
				atual.setProx(novoNo);
				this.nElem++;
				return true;
			}
		}
	}
	//inserir depois do último
	// o código está na página 11 da apostila

	//remover 1º  nó
	public boolean removerPrimeiroNo(){
		if (this.eVazia()){
			return false;
		}else{
			this.prim = this.prim.getProx();
			if (this.prim==null){
				this.ult = null;
			}
			this.nElem--;
			return true;
		}
	}
	//remover último nó
	public boolean removerUltimoNo(){
		if (this.eVazia()){
			return false;
		}else{
			if (this.prim==this.ult){
				this.prim=null;
				this.ult=null;
			}else{
				NoLSE atual = this.prim;
				while (atual.getProx()!= this.ult){ //pára no penultimo 
					atual = atual.getProx();
				}
				this.ult = atual;
				this.ult.setProx(null);
			}
			this.nElem--;
			return true;
		}
	}
	//concatenar duas listas(permanecer todos os nós na 1ª lista)
	public void concatenarListas(LSE lista2){
		if (!lista2.eVazia()){
			if (this.eVazia()){
				this.prim = lista2.prim;
				this.ult = lista2.ult;
			}else{
				this.ult.setProx(lista2.prim);
				this.ult = lista2.ult;
			}
			this.nElem += lista2.nElem;
			lista2.prim = null;
			lista2.ult = null;
			lista2.nElem=0;
		}
	}
	//remover o k-éssimo nó da lista
	//ver a execução deste método no programa Teste 02 dentro deste pacote
	public boolean removerkesimo(int k){
		if (this.eVazia()|| k>this.nElem){
			return false;
		}else{
			if (k==1){
				this.prim = this.prim.getProx();
				if (this.prim==null){
					this.ult = null;
				}
			}else{
				NoLSE atual = this.prim;
				for (int i=1;i<k-1;i++){
					atual = atual.getProx();
				}
				atual.setProx(atual.getProx().getProx());
				if (atual.getProx()==this.ult){
					this.ult=null;
				}
			}
			this.nElem--;
			return true;
		}
	}
	//lista 01 numero 13
	public boolean separarLista(LSE novaLista, int n){
		if (this.eVazia() || this.ult.getInfo().getChave()==n){
			return false;
		}else{
			NoLSE atual = this.prim;
			int cont=1;
			while (atual!=null && atual.getInfo().getChave()!=n){
				atual = atual.getProx();
				cont++;
			}
			if (atual==null){
				return false;
			}else{
				novaLista.prim = atual.getProx();
				novaLista.ult = this.ult;
				this.ult = atual;
				this.ult.setProx(null);
				novaLista.nElem = this.nElem-cont;
				this.nElem = cont;
				return true;
			}
		}
	}
	//lista 01 número 20	
	public int removerPartido(int x){
		int cont = 0;
		while (this.prim!=null && this.prim.getInfo().getChave()==x){
			this.prim = this.prim.getProx();
			cont++;
			this.nElem--;
		}
		if (this.prim==null){
			this.ult=null;
		}else{
			NoLSE atual = this.prim;
			while (atual.getProx()!=null){
				if (atual.getProx().getInfo().getChave()==x){
					cont++;
					this.nElem--;
					if (atual.getProx()!=this.ult){
						atual.setProx(atual.getProx().getProx());
					}else{
						this.ult = atual;
						this.ult.setProx(null);
					}
				}else{
					atual = atual.getProx();
				}
			}
		}
		return cont;
	}

	//transferir carro
	public void removerAtual(NoLSE at){
		this.nElem--;
		if (at==this.prim){
			this.prim = this.prim.getProx();
			if (this.prim==null){
				this.ult=null;
			}
		}else{
			NoLSE aux = this.prim;
			while (aux.getProx()!=at){
				aux = aux.getProx();
			}
			if (aux.getProx()==this.ult){
				this.ult = aux;
				this.ult.setProx(null);
			}else{
				aux.setProx(aux.getProx().getProx());
				at.setProx(null);
			}
		}
	}
	public void inserirOrdenado(NoLSE at){
		this.nElem++;
		if (this.eVazia()){
			this.prim = at;
			this.ult = at;
		}else{
			if (at.getInfo().getChave()<this.prim.getInfo().getChave()){
				at.setProx(this.prim);
				this.prim = at;
			}else{
				if (at.getInfo().getChave()>this.ult.getInfo().getChave()){
					this.ult.setProx(at);
					this.ult = at;
				}else{
					NoLSE atual2 = this.prim;
					while (atual2.getProx().getInfo().getChave()<at.getInfo().getChave()){
						atual2 = atual2.getProx();
					}
					at.setProx(atual2.getProx());
					atual2.setProx(at);
				}
			}
		}
	}
	public boolean transferirNo(LSE L2, int x){
		if (this.eVazia()){
			return false;
		}else{
			NoLSE atual =this.prim;
			while (atual!=null && atual.getInfo().getChave()!=x){
				atual = atual.getProx();
			}
			if (atual==null){
				return false;
			}else{
				this.removerAtual(atual);
				L2.inserirOrdenado(atual);
				return true;
			}
		}
	}
	//questão 3 da 1ª prova
	public LSE criarListaVetor( int [] vet){
		LSE nova = new LSE();
		if (vet[0]!=0){
			for (int i=0; i< vet.length;i++){
				nova.inserirNo(new ItemLSE(vet[i]));
			}
		}
		return nova;
	}
	//questão 4 da 1ª prova
	public LSE removerN(int n){
		if (!this.eVazia()){
			if (n>=this.nElem){
				this.prim = null;
				this.ult = null;
				this.nElem = 0;
			}else{
				for (int i=1; i<=n; i++){
					this.prim = this.prim.getProx();
				}
				this.nElem-=n;
			}
		}	
		return this;
	}

	
		
		
		}



	
}
