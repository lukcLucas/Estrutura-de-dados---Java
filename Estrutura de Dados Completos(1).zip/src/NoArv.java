
public class NoArv {
    private int valor; 
    private NoArv esq, dir;

    public NoArv(int valor, NoArv esq, NoArv dir){
        this.valor = valor;
        this.esq = esq;
        this.dir = dir;
    }

     public static void imprimirPreOrdem(NoArv n){
        System.out.print(n.valor + "  ");
        
        if(n.esq != null){
            imprimirPreOrdem(n.esq);
         }else if(n.dir != null){
            imprimirPreOrdem(n.dir);
         }

        
       
     }

     public static void imprimirEmOrdem(NoArv n){
           
        if(n.esq != null){
            imprimirEmOrdem(n.esq);

         }

         System.out.print(n.valor + "  ");
         
          if(n.dir != null){
            imprimirEmOrdem(n.dir);
         }
     }

     public static void imprimirPosOrdem(NoArv n){
           
        if(n.esq != null){
            imprimirPosOrdem(n.esq);

         }

        
         
          if(n.dir != null){
            imprimirPosOrdem(n.dir);
         }

         System.out.print(n.valor + "  ");
     }

}
