import java.util.Scanner;
public class AppExercPilha01 {
    /*
     Escreva umn programa que leia 10 numeros.Para cada numero lido,verifique e codifique 
     de acordo com as regras a seguir 
     -Se numero for par,empilhe na pilha 
     - Se o numero for impar, desempilhe um numero da pilha.caso a pilha 
     esteja vazio,
     mostre uma mensagem
     - se ao final do programa a pilha nao estiver vazio,desempilhe todos os elementos,imprimindo-os na tela

    */
    public static void main(String[] args) {
        
        Pilha<Integer> pilha = new Pilha<Integer>();

        Scanner sc = new Scanner(System.in);

        for(int i=1;i<=10;i++){
            System.out.println("Entre com um numero:");

            int num = sc.nextInt();
            //numero eh par --> empilha
            if(num %2 ==0 ){
               pilha.empilha(num);

            }
            //numero for impa --> desempilha
            else{
               Integer desempilhado = pilha.desempilha();

               if(desempilhado == null){
                   System.out.println("Pilha esta vazia");
               }else{
                System.out.println("Numero impar, desempilhando um elemento da pilha:" 
                           +desempilhado);
               }
            }
        }

        System.out.println("Todos os numero foram lidos, desempilhandos numero da pilha");
     do{
         Integer desempilhado = pilha.desempilha();

       if( desempilhado == null){
           System.out.println("Pilha esta vazia");
       }else{
           System.out.println(" Desempilhando um elemento da pilha:" 
             + desempilhado);
       }


     }while(!pilha.estaVazia());

      System.out.println("Todos os elementos foram desempilhados");

      System.out.println(pilha);
    }
  
    

}
