
public class AppPilha {
    public static void main(String[] args) {

        

        Pilha<Integer> pilha = new Pilha<Integer>();
        /*for int i=1;i<=11;i++

            pilha.empilha(i)
  
          */
       
       
         System.out.println("exercicio 5 Pilha e fila");

        
        pilha.empilha(4);
        pilha.empilha(2);
        pilha.desempilha();
        pilha.empilha(3);

        //pilha.empilha(pilha.desempilha())
        System.out.println(pilha); //3, 4
       


        
        
      

        //metodo espiar/verificar elemento do topo (peek) da pilha

        //System.out.println(pilha.topo())
       /*
        System.out.println("Desempilhando o elemento :  " + pilha.desempilha())

        System.out.println(pilha)

        System.out.println("Desempilhando o elemento :  " + pilha.desempilha())

        System.out.println(pilha) */
    }
}