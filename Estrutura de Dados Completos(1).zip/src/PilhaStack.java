import java.util.Stack;

public class PilhaStack {
    // API java de Pilha 

    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<Integer>();
        
        //Pilha estar vazio 

        System.out.println(stack.isEmpty());

        // empilhar 

        stack.push(10);
        stack.push(299);
        stack.push(67);
        stack.push(76);
        stack.push(65);
        stack.push(43);
        stack.push(25);
        stack.push(24);
        System.out.println(stack);

        // desempilha 
        System.out.println("desempilhar: " + stack.pop() );

        // espiar topo 
      
        System.out.println("Espiar topo da pilha : " + stack.peek() );
        
        

        System.out.println(stack);
    }
}
