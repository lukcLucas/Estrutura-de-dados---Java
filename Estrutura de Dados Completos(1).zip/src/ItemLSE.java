public class ItemLSE {
    // tem varios atributos, dentre eles

    private int chave;


    /**
     * 
     *  @param chave
     * 
     * 
     * 
     */


     public  ItemLSE(int chave){

        this.chave = chave;



    }

    public int getChave(){

        return chave;
    }


    public void setChave(int chave){

        this.chave = chave;
    }

    @Override
    public String toString(){

        return "ItemLSE [ chave" + chave + "]";
    }


}
