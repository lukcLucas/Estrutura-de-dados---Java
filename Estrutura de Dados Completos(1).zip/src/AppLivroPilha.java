public class AppLivroPilha {
    /*
    Ultilize a classe pilha (criada) e desenvolva os 
    seguinte items:

    1- crie uma pilha com capacidade para 20 livro

    2- insira 6 livro na pilha;cada livro contem nome,isbn,ano de lancamento e autor

    3- crie um exemplo para ultilizar cada metodo da classe Pilha 

    

    */

    public static void main(String[] args) {
        
        Pilha<Livro> pilha = new Pilha<Livro>(6);

        Livro livro1 = new Livro();

        Livro livro2 = new Livro();

        Livro livro3 = new Livro();

        Livro livro4 = new Livro();
        Livro livro5 = new Livro();

        Livro livro6 = new Livro();
        


        livro1.setNome("Estrutura de Dados");
        livro1.setAutor("Caio");
        livro1.setAnoLancamento(2018);
        livro1.setIsbn("801c2xx8y2");
        System.out.println("\n");


        livro2.setNome("Eletromagnetismo ");
        livro2.setAutor("Clayton R. Paul");
        livro2.setAnoLancamento(2017);
        livro2.setIsbn("701b4yy8z5");
        System.out.println("\n");

        livro3.setNome("Rede de Computadores  ");
        livro3.setAutor("Tanenbaum");
        livro3.setAnoLancamento(2017);
        livro3.setIsbn("701b4yy8z5");
        System.out.println("\n");

        livro4.setNome("Sistema Operacional   ");
        livro4.setAutor("Tanenbaum");
        livro4.setAnoLancamento(2017);
        livro4.setIsbn("721b4xy8h5");
        System.out.println("\n");

        livro5.setNome("Sistema Embarcados   ");
        livro5.setAutor("Tanenbaum");
        livro5.setAnoLancamento(2017);
        livro5.setIsbn("431b5yj8z6");
        System.out.println("\n");

        livro6.setNome("The Witcher - Espada  do Destino");
        livro6.setAutor("Andrzej Sapkowski");
        livro6.setAnoLancamento(1992);
        livro6.setIsbn("555c8fhtz5");
        System.out.println("\n");

        
       System.out.print("Pilha de livros criadas, pilha estar vazia ?" + pilha.estaVazia());
       System.out.println("\n");
       System.out.println("Empilhando livros na pilhas");
       System.out.println("\n");
        pilha.empilha(livro1);
        pilha.empilha(livro2);
        pilha.empilha(livro3);
        pilha.empilha(livro4);
        pilha.empilha(livro5);
        pilha.empilha(livro6);
        System.out.println("\n");

        System.out.println(pilha.tamanho() + " livros foram empilhados");
        System.out.println("\n");
        System.out.println(pilha);
        System.out.println("\n");
        System.out.print("Pilha de livros criadas, pilha estar vazia ?" 
        + pilha.estaVazia());
        System.out.println("\n");

        System.out.println("Verificando o topo da pilha de livro:" 
        + pilha.topo());
        System.out.println("\n");

        System.out.println("Desempilhando livros da pilha:");
        System.out.println("\n");
        do{
             System.out.println("Desempilhando livro da pilha"
              + pilha.desempilha() );
              System.out.println("\n");
        }while(!pilha.estaVazia());

        System.out.println("\n");
        
        System.out.println("Todos os livros foram desempilhados,pilha estar vazia"
        + pilha.estaVazia());


    }

    
   
    


}
