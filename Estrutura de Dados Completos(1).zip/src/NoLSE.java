public class NoLSE {

     private ItemLSE info;
     private NoLSE prox;

     /**
      * 
       @param info
      */

      public NoLSE(ItemLSE info){
          this.info = info;
          this.prox = null;  
       }

       public ItemLSE getInfo(){

        return info;
    }
    public void setInfo(ItemLSE info){
        this.info = info;
    }
    public NoLSE getProx(){
        return prox;
    }

    public void setProx(NoLSE prox){
        this.prox = prox;
    }
    @Override 

    public String toString(){
        
        return "NoLSE  [info" + info + "]";
    }
}
        

