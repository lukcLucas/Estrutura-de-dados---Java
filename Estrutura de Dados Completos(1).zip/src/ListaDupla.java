public class ListaDupla {
    /**
     * 
     *  
     * 
    
 * 
 */
   
   private NoDupla prim, ult; //objetos da classe NoDupla
   private int nElem;  //armazena a quantidade de nós da lista


   //construtor, gets e sets 

   public ListaDupla(){
        this.prim = null;
        this.ult = null;
        this.nElem = 0;
   }

    public NoDupla getPrim(){
        return prim;
    }

    public void setPrim(NoDupla prim){
        this.prim = prim;
    }

    public NoDupla getUlt(){
        return ult;
    }

    public void setUlt(NoDupla ult){

        this.ult = ult;
    
    }

    public int tamanho(){
        return nElem;
    }
        



   


 /* Operações
 * eVazia: retorna true se a lista estiver vazia e false caso contrário
 * insereUltimo: insere um No no final da lista
 * insereInicio: insere um No no início da lista
 * pesquisa: retorna o nó que contém o valor a ser pesquisado
 * ou Null se não encontrar
 * pesquisaAoContrario: faz a pesquisa do fim para o início
 * remove: remove o nó que contém o valor passado. Retorna true
 * se a remoção foi bem sucedida e false caso contrário
 * toString
 */

















   // metodo eVazia: retorna true se a lista estiver vazia e false caso contrário

   public boolean eVazia(){
        
     if(this.nElem==0){
         return true;
     }

     return false;
   }

   




 //insereUltimo: insere um No no final da lista



  //insere um novo nó no final da lista ou se a lista estiver vazia, insere
	// o primeiro nó na lista
	public void insereFim (int num){
		NoDupla novoNo = new NoDupla (num);
		if (this.eVazia())
			this.prim = novoNo; 
		else { 
            this.ult.setProx(novoNo);
			novoNo.setAnt(this.ult);
			
		}	
		this.ult = novoNo;
		this.nElem++;
	}


 //insereInicio: insere um No no início da lista



  public void insereInicio(int num){
    NoDupla novoNo = new NoDupla (num);
    if (this.eVazia()) {
    this.ult = novoNo;
    }else {
    this.prim.setAnt(novoNo);
    novoNo.setProx(this.prim);
    }
    this.prim = novoNo;
    this.nElem++;
  }





//pesquisa: retorna o nó que contém o valor a ser pesquisado ou Null 
//se não encontrar

//pesquisaAoContrario: faz a pesquisa do fim para o início



//retorna o endereco do nó que esta contendo o valor a ser procurado



public NoDupla pesquisa (int num) {
    NoDupla aux = this.prim;
    while (aux != null) {
    if (aux.getInfo()==num) {
    return aux;
    }
    aux = aux.getProx();
    }
    return null;
    }
    public NoDupla pesquisaAoContrario (int num) {
    NoDupla aux = this.ult;
    while (aux!=null) {
    if (aux.getInfo()==num) {
    return aux;
    }
    aux = aux.getAnt();
    }
    return null;
    }
    /*
    * remove: remove o nó que contém o valor passado. Retorna true se a
    * remoção foi bem sucedida e false caso contrário
    */
    


     //remove: remove o nó que contém o valor passado. Retorna true se 
//a remoção foi bem sucedida e false caso contrário

//remove um determimando nó em qualquer posicao na lista 


     public boolean remove(int num){
         NoDupla aux = this.pesquisa(num);
         if(aux==null){
             return false;
         }else if(aux==this.prim){
              if(aux.getProx()==null){
                    this.ult=null;
              }else{
                  aux.getProx().setAnt(null);
              }
              this.prim = aux.getProx();
         }else if(aux==this.ult){
              aux.getAnt().setProx(null);
              this.ult = aux.getAnt();
         }else{
            aux.getAnt().setProx(aux.getProx());
            aux.getProx().setAnt(aux.getAnt());
           
         }
         this.nElem--;

         return true;
     }


     

     //toString

  


     public String toString() {
        String str="";
        NoDupla aux = this.prim;
        while (aux != null) {
        str += aux.getInfo()+" ";
        aux=aux.getProx();
        }
        return str;
        }
        public String toStringAoContrario() {
        String str="";
        NoDupla aux = this.ult;
        while (aux != null) {
        str += aux.getInfo()+" ";
        aux=aux.getAnt();
        }
        return str;
        }
        /*
        * Escreva um metodo para retornar o no da k-esima posicao
        */
        
        public NoDupla getPos (int pos) {
            NoDupla aux;
            if (pos<0 || pos >=nElem) {
            return null;
            }else {
            aux = prim;
            for (int i=0; i< pos; i++) {
            aux = aux.getProx();
            }
            return aux;
            }
            }
    /** Escreva um metodo para inserir um novo no na k-esima posicao
 */


  
   public boolean insere (int elem, int pos){
        

    NoDupla novoNo, aux, ant;
    if (pos<0 || pos>this.nElem) {
       return false;
    }else {
      novoNo = new NoDupla(elem);
      if (pos==0) {
      insereInicio(elem);
    }else if (pos==nElem) {
      insereFim(elem);
    }else {
      novoNo = new NoDupla(elem);
      aux = prim;
      for (int i=0; i<pos; i++) {
         aux = aux.getProx();
        }
      ant = aux.getAnt();
      ant.setProx(novoNo);
      novoNo.setAnt(ant);
      novoNo.setProx(aux);
      aux.setAnt(novoNo);
      this.nElem++;
    }
    }
    return true;
   }

  /*
 * Escreva um método para remover o k-ésimo nó da lista
 */
 public boolean removePos (int pos) {
     NoDupla ant, aux = getPos(pos);
     if(aux == null){
         return false;
     }else{
          if(aux==prim){ //testa ser for um elemento
            prim = aux.getProx();
            if(prim==null){
                ult = null;
            }else{
                prim.setAnt(null);
            }
          }else if(aux ==ult){ //testa se for o ultimo
              ult = aux.getAnt();
              ult.setProx(null);
          }else{
              ant = aux.getAnt();
              aux = aux.getProx();
              ant.setProx(aux);
              aux.setAnt(ant);

          }
     }
     this.nElem--;

     return true;


 }



 /*
 * Escreva um método que recebe uma Lista Duplamente Encadeada (L1)
 * e concatena esta lista no final da lista chamadora (objeto do método)
 */

  public void concatena(ListaDupla L1){
      if(!L1.eVazia()){
           if(this.eVazia()){
                this.prim = L1.prim;
                this.ult = L1.ult;
           }else{
               this.ult.setProx(L1.prim);
               L1.prim.setAnt(this.ult);
               this.ult =L1.ult;

           }
           L1.prim = null;
           L1.ult = null;
           this.nElem = this.nElem+L1.nElem;
      }
  }








}
