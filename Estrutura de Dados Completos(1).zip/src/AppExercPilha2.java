import java.util.Scanner;
public class AppExercPilha2 {
     /*
      
      Escreva um programa que leia 10 numeros.Para cada numero lido, verifique e codifique de acordo
      com as regras a seguir:

      -se o numero for par, empilhe na pilha chamada par
      - se o numero for impar,empilhe na pilha chamada impar
      - se o numero for vazio(0),desempilhe um elemento de cada pilha.Caso
      alguma pilha esteja vazia, mostre uma mensagem de erro na tela.

      Ao final do programa desempilhe todos os elementos das duas pilhas,
      imprimindo-os na tela


     */

   public static void main(String[] args) {
       
    Pilha<Integer> par = new Pilha<Integer>();
    Pilha<Integer> impar = new Pilha<Integer>();
    
    Scanner sc  = new Scanner (System.in);
    
    for(int i=1;i<=10;i++){
        System.out.println("Entre com um numero:  ");
        int num =sc.nextInt();

        if(num == 0){

            Integer desempilhado = par.desempilha();
            
             if(desempilhado == null){
                 System.out.println("Pilha Par Vazia ");
             }else{
                System.out.println("Desempilhando da pilha par:  " 
                + desempilhado);
             }

            //pilha impar
            Integer desemp = impar.desempilha();

            if(desemp == null){
                System.out.println("Pilha Impar Vazia ");
            }else{
               System.out.println("Desempilhando da pilha Impar:  " 
               + desemp);
            }

        }else if(num % 2 == 0){
            System.out.println(("Numero par, empilhado na pilha par" + num));
            par.empilha(num);
        }else{
            System.out.println(("Numero impar, empilhado na pilha impar" + num));
            impar.empilha(num);
        }
        
    }


    
    System.out.println("Pilha Impar: " + impar);
    System.out.println("Pilha Par" + par);







    System.out.println("Desempilhando todos os numeros da pilha par ");
    




    do{
        System.out.println("Desempilhando da pilha par : "
         + par.desempilha());

    }while(!par.estaVazia());

    System.out.println("Desempilhando todos os numeros da pilha Impar ");

    do{
        System.out.println("Desempilhando da pilha Impar : "
         + impar.desempilha());

    }while(!impar.estaVazia());
    
   
   }

}
