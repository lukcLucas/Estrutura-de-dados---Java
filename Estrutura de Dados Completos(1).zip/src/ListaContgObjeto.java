public class ListaContgObjeto {
    private Object[] elementos;
    private int tamanho;


    public ListaContgObjeto(int capacidade){
        this.elementos = new Object[capacidade];
        this.tamanho = 0; // inializar o tamanho
    }
    

     
    
    // add elemento no final da lista 
    public boolean adiciona(Object elemento){
        this.aumentaCapacidade();
       if(this.tamanho < this.elementos.length){
        this.elementos[this.tamanho] = elemento;
        this.tamanho++; 
        return true;
       } 

       return false;

        
    } //Add elemento em qualquer posicao

    public boolean adiciona(int posicao, Object elemento){
         this.aumentaCapacidade();
        // verificar posicao do usuario ta passando pelo metodo e uma posicao valida 
        if(!(posicao >= 0 && posicao < tamanho)){
            throw new IllegalArgumentException("Posicao invalida");
        }

       // move todo os elementos

       for(int i=this.tamanho-1; i>=posicao;i--){
            // remover elementos
           this.elementos[i + 1] = this.elementos[i];
       }
       // 0 1 2 3 4 5 6 = tamanho = 5
       // B C E F G + +
       // i=5


       this.elementos[posicao] = elemento;
       this.tamanho++;

        
        return false;
    }


    //adicionar elemento aumentar capacidade da lista

    private void aumentaCapacidade(){
        if(this.tamanho == this.elementos.length){

         Object[] elementosNovos = new Object[this.elementos.length *2];
          
         for (int i=0;i<this.elementos.length;i++){
            elementosNovos[i] = this.elementos[i];
         }
         
         this.elementos = elementosNovos;
        }
    }

    // metodo remove ---> remover o indice da lista 

    public void remove(int posicao ){
        if(!(posicao >= 0 && posicao < tamanho)){
            throw new IllegalArgumentException("Posicao invalida");
        }

       for(int i=posicao;i<this.tamanho-1;i++){
          this.elementos[i] = this.elementos[i + 1];
          
       }

       this.tamanho--;


    }

    




   // obter elementos de uma posicao da lista 
    public Object busca(int posicao){

        if(!(posicao >= 0 && posicao < tamanho)){
            throw new IllegalArgumentException("Posicao invalida");
        }
        return this.elementos[posicao];
    }

    // verificar se elementos exixte na lista 

    public int  busca(Object elemento){
          for(int i=0;i<this.tamanho;i++){
               if(this.elementos[i].equals(elemento)){
                   return i;
               }
          }
          return -1; // -1 eh uma posicao que nao existe 
    }

   


  public int tamanho(){
      return this.tamanho; // metodo para expor o tamanho 
  }
  //concartenar string 
  @Override 
  public String toString(){

       StringBuilder s = new StringBuilder();
       s.append("[");
    
       for(int i = 0; i < this.tamanho-1; i++){
            s.append(this.elementos[i]) ;
            s.append(", ");
           
       }if(this.tamanho > 0){
       s.append(this.elementos[this.tamanho-1]);
    }
      s.append("]");

      return  s.toString() ;
  } 
}
