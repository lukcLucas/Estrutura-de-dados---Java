public class AppListaDupla {
    public static void main(String[] args) {
        
        ListaDupla lista = new ListaDupla();

        lista.insereInicio(12);
        lista.insereInicio(13);
        lista.insereInicio(14);
        lista.insereInicio(15);
        lista.insereInicio(16);
        lista.insereInicio(17);
        lista.insereInicio(18);
        lista.insereInicio(19);
        lista.insereInicio(20);
        lista.insereInicio(21);
        lista.insereInicio(22);
        lista.insereFim(1);
        lista.insereFim(2);
        lista.insereFim(3);
        lista.insereFim(4);
        lista.insereFim(5);
        lista.insereFim(6);
        lista.insereFim(7);
        lista.insereFim(8);
        lista.insereFim(9);
        lista.insereFim(10);
        
        System.out.println(lista.toString());
        

       
        
        System.out.println(lista.pesquisa(5));

    }
}
