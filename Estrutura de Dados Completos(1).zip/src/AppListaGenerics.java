public class AppListaGenerics {
    public static void main(String[] args) {
         ListaGenerics<String> lista = new ListaGenerics<String>(10);

         lista.adiciona("A");
         lista.adiciona("B");
         lista.adiciona("C");
         lista.adiciona("D");
         lista.adiciona("E");
         lista.adiciona("F");
         

         System.out.println("Lista Generica");
         System.out.println("Exercicio 01 Metodo Contem");
         System.out.println(lista.contem("A")); //TRUE
         System.out.println(lista.contem("B"));//TRUE
         System.out.println(lista.contem("E"));//FALSE
         System.out.println("Exercicio 02 Metodo ultimo indice ");
         /*
          Melhore a classe ListaGenerics e implemente o metodo ultimoIndice,semelhante
          ao metodo lastIndexOf da classe ArrayList
         */

         System.out.println(lista.ultimoIndice("A"));

         System.out.println("Exercicio 03 Metodo remover elemento ");
        /*
         Melhore a classe ListaGenerics e implemente o
          metodo remover(T elemento),onde sera possivel 
          remover um elementos da lista passando o mesmo 
          como parametro.
        */
        System.out.println(lista);

        lista.remove("A");

        System.out.println(lista);

        
        lista.remove("E");
        
        System.out.println(lista);

        
        lista.remove("C");
        
        System.out.println(lista);


        System.out.println("Exercicio 04 Metodo Obtem(get) ");

       /*
          Melhore a classe Lista e implemente o metodo obtem(int posicao),
           onde sera possivel obter o elemento dada uma posicao do vetor.Esse metodo
           e semelhante ao metodo get(int posicao) da classe arrayList 
       */

      System.out.println(lista.obtem(0));
      System.out.println(lista.obtem(3));
      System.out.println(lista.obtem(5));
      

      System.out.println("Exercicio 05 Metodo limpar todos elementos ");
       
       // lista.limpar()

       // System.out.println(lista)

        //System.out.println(lista)
         
    }
}
