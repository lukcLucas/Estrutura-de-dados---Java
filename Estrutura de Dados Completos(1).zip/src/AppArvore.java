

    

public class AppArvore {

	public static void main(String[] args) {
        
        //NoArv no = new NoArv(15, new NoArv(10, null, null), new NoArv(50, new NoArv(20, null, null), null))

       // new NoArv(valor, esq, dir)
        NoArv no10 = new NoArv(10, null, null);

        NoArv no20 = new NoArv(20, null, null);

        NoArv no50 = new NoArv(50, no10, null);

        NoArv no15 = new NoArv(15, no10, no50);
        
      
       

       
        
    
    
      

      NoABB arv = new NoABB(5);
      NoABB.montaArvore(arv, arv);


      NoABB n5 = new NoABB(5);
      NoABB.montaArvore(n5, arv);


      NoABB n20 = new NoABB(20);
      NoABB.montaArvore(n20, arv);


      NoABB n33 = new NoABB(33);
      NoABB.montaArvore(n33, arv);

      NoABB n1 = new NoABB(1);
      NoABB.montaArvore(n1, arv);


      NoABB n2 = new NoABB(2);
      NoABB.montaArvore(n2, arv);

      NoABB n7 = new NoABB(1);
      NoABB.montaArvore(n7, arv);

       NoABB n30 = new NoABB(1);
      NoABB.montaArvore(n30, arv);
      


      System.out.println("Pre-ordem");
      NoABB.imprimirPreOrdem(arv);
      System.out.println("");
      System.out.println("Emordem");
      NoABB.imprimirEmOrdem(arv);
      System.out.println("");
      System.out.println("Pos-ordem");
      NoABB.imprimirPosOrdem(arv);




    
    }
}


